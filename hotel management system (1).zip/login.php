<!DOCTYPE HTML> 

<html> 

<head> <title>Sign-In</title> 

<link rel="stylesheet" type="text/css" href="style-sign.css">
</head>
<body id="body"> 
<div id="Sign-In"> 
<fieldset style="width:30%">
<legend>LOG-IN HERE</legend> 
<form action="password_verification.php" method="post">
<?php
if(isset($_GET['error']))
{
	echo "<span style='color:red'>".$_GET['error']."</span><br>";
}
?>
Email <br><input type="email" name="email" size="40"><br> 
Password <br><input type="password" name="pass" size="40"><br>
<input id="button" type="submit" name="submit" value="Log-In"> 
</form>
</fieldset>
</div>
</body>
</html>
<?php
include('conn.php');
if(isset($_POST['Submit']))
{
	$name=mysqli_real_escape_string($conn,check($_POST['name']));
	$email=mysqli_real_escape_string($conn,check($_POST['email']));
	$room=mysqli_real_escape_string($conn,$_POST['room']);
	$member=mysqli_real_escape_string($conn,$_POST['member']);
	$day=mysqli_real_escape_string($conn,$_POST['day']);
	$month=mysqli_real_escape_string($conn,$_POST['month']);
	$year=mysqli_real_escape_string($conn,$_POST['year']);
	
	
if(empty ($name)||empty($email)||empty($member)||empty($room)||empty($day)||empty($month)||empty($year))
	{
		header("location:intro1.php?error= all fields are required");
	}
	else
	{
			$date=$day." ".$month." ".$year;
			$sql="INSERT into hms1(Name,Email,Rooms,Members,Date) VALUES ('$name','$email','$room','$member','$date')";
			if(mysqli_query($conn,$sql))
			{
				header('location:intro1.php?error= Reservation Successful');
			}
			else
			{
					header('location:intro1.php?error=Reservation failed');
			}
			/*echo md5($password)."<br>";
			echo sha1($password)."<br>";
			echo password_hash($password,PASSWORD_DEFAULT)."<br>";*/
		
		
	}	

}	

function check($data)
{
	$data =htmlspecialchars($data);
	$data =stripslashes($data);
	$data =trim($data);
	return $data;
}
?>
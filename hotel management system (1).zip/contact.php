<?php include 'header.php';?>
<div class="container">

<h1 class="title">Contact</h1>

<form action="echocontact.php" method="post">
<?php
	
	if(isset($_GET['error']))
	{
		echo "<span style='color: red'>".$_GET['error']."</span><br>";
	}
?>
<!-- form -->
<div class="contact">





		<div class="col-sm-6 col-sm-offset-3">
			<div class="spacer">   		

       		<h4>Write to us</h4>
			<form role="form">
			<div class="form-group">	
			<input type="text" class="form-control" id="name" name="name" placeholder="Name">
			</div>
			<div class="form-group">
			<input type="email" class="form-control" id="email" name="email"placeholder="Enter email">
			</div>
			<div class="form-group">
			<input type="phone" class="form-control" id="phone"  name="phone1" placeholder="Phone">
			</div>
			<div class="form-group">
			<textarea type="email" class="form-control"  placeholder="Message" name="message" rows="4"></textarea>
			</div>
					
			<button type="submit" class="btn btn-default" name="submit" >Send</button>
			</form>
			</div>


       	</div>





       </div>
</div>
</div>
<!-- form -->

</div>
<?php include 'footer.php';?>